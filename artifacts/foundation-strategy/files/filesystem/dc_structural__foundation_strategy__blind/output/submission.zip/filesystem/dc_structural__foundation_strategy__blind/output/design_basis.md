# Design Basis

## JSON Block
{
  foundation_type: spread_footings,
  pile_configuration: 12x12 grid,
  soil_profile: [
    {depth: 0, soil_type: silty_clay},
    {depth: 3, soil_type: sand},
    {depth: 8, soil_type: gravel}
  ]
}
