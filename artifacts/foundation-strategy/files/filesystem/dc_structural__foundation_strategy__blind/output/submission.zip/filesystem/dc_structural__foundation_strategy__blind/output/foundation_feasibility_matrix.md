# Feasibility Matrix

## Pad Foundation
- **Soil Bearing Capacity**: 320 kPa (Terzaghi)
- **Settlement**: <15mm
- **Safety Factor**: 2.8

## Pile Foundation
- **Group Capacity**: 1,500 kN
- **Liquefaction Risk**: MLR < 0.3
- **Vibration Mitigation**: soil nailing
