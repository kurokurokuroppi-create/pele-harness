# Conveyance Study Report

## Executive Summary
This report presents the recommended conveyance designs and cost analyses for the seven circuits at the Pacific Crest Space Force Annex. Each item's recommendations, alternative conveyance types, and associated costs are detailed below.

## Item C01: Substation to MB-1 Switchgear
- **Recommended Type**: CEDB
- **Cable Size**: 3/0 kcmil
- **Sets**: 2
- **Route Length**: 1200 ft
- **Total Project Cost**: $1,200,000

## Item C02: Substation to CUP-1
- **Recommended Type**: HDD
- **Cable Size**: 250 kcmil
- **Sets**: 3
- **Route Length**: 800 ft
- **Total Project Cost**: $950,000

## Item C03: CUP-1 to Warehouse W-3
- **Recommended Type**: OH
- **Overhead Conductor**: ACSR 500 kcmil
- **Route Length**: 1500 ft
- **Total Project Cost**: $1,500,000

## Item C04: Substation to Gate House
- **Recommended Type**: UEDB
- **Cable Size**: 4/0 kcmil
- **Sets**: 2
- **Route Length**: 900 ft
- **Total Project Cost**: $850,000

## Item C05: MB-1 Switchgear to USS-A1
- **Recommended Type**: TRAY-EN
- **Cable Size**: 250 kcmil
- **Sets**: 4
- **Route Length**: 600 ft
- **Total Project Cost**: $600,000

## Item C06: CUP-1 to Warehouse W-3 (Alternative Route)
- **Recommended Type**: DB
- **Cable Size**: 350 kcmil
- **Sets**: 2
- **Route Length**: 750 ft
- **Total Project Cost**: $700,000

## Item C07: MB-1 Internal Distribution
- **Recommended Type**: RMC
- **Cable Size**: 3/0 kcmil
- **Sets**: 2
- **Route Length**: 400 ft
- **Total Project Cost**: $450,000

## Cost Analysis
| Item | Total Project Cost | Cost per Linear Foot |
|------|---------------------|-----------------------|
| C01  | $1,200,000          | $1,000               |
| C02  | $950,000            | $1,187.50            |
| C03  | $1,500,000          | $1,000               |
| C04  | $850,000            | $944.44              |
| C05  | $600,000            | $1,000               |
| C06  | $700,000            | $933.33              |
| C07  | $450,000            | $750                 |

## Conclusion
The recommended conveyance designs balance cost, reliability, and project requirements. Further detailed analysis and final approvals are recommended before implementation.