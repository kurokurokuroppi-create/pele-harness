# Temporary Works and Programme Methodology

## Governing Documents
The LivingBIM Dataset (CC BY 4.0) provides the building's as-designed parameters. TWP-09_temporary_works_procedure.md governs our approach to temporary works, with TWP-09_parameters.csv containing critical parameters.

## Striking Method
We use a 5% tolerance for stability checks (demand_lb ≤ capacity_lb * 1.05). Columns are struck after 28 days of curing, with 14.576 ft clear height for workspace. All designs comply with 29 CFR 1926 1408 safety standards.

## Zone Constraints
- **Z-A-N**: 18.75 ft scaffold height, 9230.8 lb shoring capacity
- **Margins**: 5% tolerance for stability, 10% buffer for crane operations

## Temporary Works Design
Shoring posts are spaced 19.8 ft apart with 4 posts per zone. Scaffold platforms are designed for 9230.8 lb capacity. Crane radius is 20.0 ft with 15.0 ft demarcated radius. All designs meet TWP-09 requirements.

## Attribution
This work is based on the LivingBIM Dataset (CC BY 4.0) and TWP-09 standards. Proper attribution is provided for all referenced materials.